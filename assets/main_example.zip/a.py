#! /usr/env/bin python
import b
print("script a is importing script b")
