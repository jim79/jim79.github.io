import b
print("script a is importing script b")
