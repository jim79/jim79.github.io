#! /usr/env/bin python
print("__name__ equals " + __name__)

if __name__ == "__main__":
	print("printed when script b is executed")


